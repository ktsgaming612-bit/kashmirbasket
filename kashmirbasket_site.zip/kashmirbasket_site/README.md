# Kashmir Basket — Static Website
This is a simple eCommerce-style landing page for *Kashmir Basket* built with Tailwind CSS.
Deploy it on **GitHub Pages** easily.

## Deploy Steps
1. Create a GitHub repo.
2. Upload all files from this ZIP.
3. Enable GitHub Pages (Settings → Pages → Source: main branch /root).
4. Your site will be live at `https://<username>.github.io/kashmirbasket/`.
